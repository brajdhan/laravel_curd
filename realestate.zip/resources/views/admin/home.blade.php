
@include('admin.layouts.header')
@include('admin.layouts.navbar')
@include('admin.layouts.aside')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Home</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('')}}/admin/create">Home</a></li>
              <li class="breadcrumb-item active">Home</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
              
          <!-- SELECT2 EXAMPLE -->
          <div class="card card-default">
            <div class="card-header">
              <h3 class="card-title" class="btn btn-primary float-right">Home Banner
                {{-- <a href="{{url('/')}}/admin/create" class="btn btn-primary float-right"> Add Banner</a> --}}
              </h3>
              
              
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-card-widget="remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
              <a href="{{route('admin.create')}}">
                <button class="btn btn-primary btn-sm d-inline-block m-2 float-right">Add</button>
              </a>
            </div>
            <!-- /.card-header -->
            {{-- {{print_r($banners)}} --}}
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr No.</th>
                  <th>Banner</th>
                  <th>Text1</th>
                  <th>Text2</th>
                  <th>Text3</th>
                  <th>Text4</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                  @foreach ($banners as $banner )
                  <tr>
                    <td>{{ $banner->id }}</td>
                    <td>
                      <img src="{{ url('storage/'.$banner->image) }}" alt="banner" width="100" srcset="">
                      </td>
                    <td>{{ $banner->text1 }}</td>
                    <td>{{ $banner->text2 }}</td>
                    <td>{{ $banner->text3 }}</td>
                    <td>{{ $banner->text4 }}</td>
                   
                    <td> <a href="{{ route('admin.edit',['id'=>$banner->id ])}}" class="badge badge-primary">Edit</a></td>
                  </tr>
                  @endforeach
                
                <tbody>
              </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
             
            </div>
          </div>
          <!-- /.card -->
      </form>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@include('admin.layouts.sidebar')
@include('admin.layouts.footer')