
@include('admin.layouts.header')
@include('admin.layouts.navbar')
@include('admin.layouts.aside')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Home</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('')}}/create">Home</a></li>
              <li class="breadcrumb-item active">Home</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <form action="{{$url}}" method="post" enctype="multipart/form-data">
          @csrf
          
          <!-- SELECT2 EXAMPLE -->
          <div class="card card-default">
            <div class="card-header">
              <h3 class="card-title">{{$title}}</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-card-widget="remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                    <label>Text 1 (Min :12 Charector)</label>
                    <input type="text" name="text1" class="form-control" value="@isset($id)
                    {{ nl2br(e($banner->text1)) }}  @endisset {{old('text1')}} ">
                    <small id="helpId" class=" text-danger">
                        @error('text1')
                        {{$message}}
                       
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                    <label>Text 2 (Min :12 Charector)</label>
                    <input type="text" name="text2" class="form-control" value="{{old('text2')}} @isset($id)
                    {{$banner->text1}}  @endisset ">
                    <small id="helpId" class=" text-danger">
                        @error('text2')
                        {{$message}}
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- /.col -->
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Text 3 (Min :12 Charector)</label>
                    <input type="text" name="text3" class="form-control" value="{{old('text3')}} @isset($id)
                    {{$banner->text1}}  @endisset ">
                    <small id="helpId" class=" text-danger">
                        @error('text3')
                        {{$message}}
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                    <label>Text 4 (Min :12 Charector)</label>
                    <input type="text" name="text4" class="form-control" value="{{old('text4')}} @isset($id)
                    {{$banner->text1}}  @endisset ">
                    <small id="helpId" class=" text-danger">
                        @error('text4')
                        {{$message}}
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- /.col -->

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="">Image</label>
                        <input type="file" name="file" class="form-control">
                        <small id="helpId" class=" text-danger">
                            @error('file')
                            {{$message}}
                            @enderror
                        </small>
                      </div>
                </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <button class="btn btn-primary">Submit</button>
            </div>
          </div>
          <!-- /.card -->
      </form>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@include('admin.layouts.sidebar')
@include('admin.layouts.footer')