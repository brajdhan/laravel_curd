
@include('admin.layouts.header')
@include('admin.layouts.navbar')
@include('admin.layouts.aside')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Home</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('')}}/create">Home</a></li>
              <li class="breadcrumb-item active">Home</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <form action="{{$url}}" method="post" enctype="multipart/form-data">
          @csrf
          
          <!-- SELECT2 EXAMPLE -->
          <div class="card card-default">
            <div class="card-header">
              <h3 class="card-title">{{$title}}</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-card-widget="remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                    <label>Heading</label>
                    <input type="text" name="heading" class="form-control" value="@isset($id)
                    {{ $banner->heading }}  @endisset {{old('heading')}} ">
                    <small id="helpId" class=" text-danger">
                        @error('heading')
                        {{$message}}
                       
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                    <label>About Text</label>
                    <input type="text" name="about_text" class="form-control" value="{{old('about_text')}} @isset($id)
                    {{$banner->about_text}}  @endisset ">
                    <small id="helpId" class=" text-danger">
                        @error('about_text')
                        {{$message}}
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                    <label> Sub Text 1</label>
                    <input type="text" name="sub_text1" class="form-control" value="@isset($id)
                    {{ $banner->sub_text1 }}  @endisset {{old('sub_text1')}} ">
                    <small id="helpId" class=" text-danger">
                        @error('sub_text1')
                        {{$message}}
                       
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                    <label> Sub Text 2</label>
                    <input type="text" name="sub_text2" class="form-control" value="{{old('sub_text2')}} @isset($id)
                    {{$banner->sub_text2}}  @endisset ">
                    <small id="helpId" class=" text-danger">
                        @error('sub_text2')
                        {{$message}}
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- /.col -->
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Sub Text 3</label>
                    <input type="text" name="sub_text3" class="form-control" value="{{old('sub_text3')}} @isset($id)
                    {{$banner->sub_text3}}  @endisset ">
                    <small id="helpId" class=" text-danger">
                        @error('sub_text3')
                        {{$message}}
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                    <label> Sub Text 4</label>
                    <input type="text" name="sub_text4" class="form-control" value="{{old('sub_text4')}} @isset($id)
                    {{$banner->sub_text4}}  @endisset ">
                    <small id="helpId" class=" text-danger">
                        @error('sub_text4')
                        {{$message}}
                        @enderror
                    </small>
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- /.col -->

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="">Image1</label>
                        <input type="file" name="image1" class="form-control">
                        <small id="helpId" class="text-danger">
                            @error('image1')
                            {{$message}}
                            @enderror
                        </small>
                      </div>

                      <div class="form-group">
                        <label for="">Image2</label>
                        <input type="file" name="image2" class="form-control">
                        <small id="helpId" class=" text-danger">
                            @error('image2')
                            {{$message}}
                            @enderror
                        </small>
                      </div>
                </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <button class="btn btn-primary">Submit</button>
            </div>
          </div>
          <!-- /.card -->
      </form>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@include('admin.layouts.sidebar')
@include('admin.layouts.footer')