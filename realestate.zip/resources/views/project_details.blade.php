<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Project Details || Brajdhan - Real Estate </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- CSS
	============================================ -->
   
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
</head>

<body>

<!-- Header Section Start -->
@include('layouts.header')
<!-- Header Section Start -->

<!-- Breadcrumb -->
<div class="breadcrumb-area section" style="background-image: url(assets/images/bg/breadcrumb.jpg)">
    <div class="container">
        <div class="breadcrumb pt-75 pb-75 pt-sm-70 pb-sm-40 pt-xs-70 pb-xs-40">
            <div class="row">
                <div class="col">
                    <h2>Project Details</h2>
                    <!-- breadcrumb-list start -->
                    <ul class="breadcrumb-list">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active">Project Details</li>
                    </ul>
                    <!-- breadcrumb-list end -->
                </div>
            </div>
        </div>
    </div>
</div>
<!--// Breadcrumb -->
    
<!-- Page Conttent -->
<main class="page-content section"> 
   
    <!-- Featured Properites Start -->   
    <div class="properites-sidebar-wrap pt-80 pt-md-60 pt-sm-40 pt-xs-30 pb-110 pb-md-90 pb-sm-70 pb-xs-60">
        <div class="container">
            
            <div class="row">
                <div class="col-lg-4 col-xl-3 col-12 order-lg-2 order-2">
                    <div class="row widgets">
                        <div class="col-lg-12">
                            <div class="single-widget widget">
                                <h4 class="widget-title">
                                    <span>Complated Project</span>
                                </h4>
                                <div class="row single-propertiy-wigets">
                                    <div class="col-lg-12 col-md-6 single-propertiy mb-30">
                                        <a href="#"><img src="assets/images/propertes/w-propertie-01.jpg" alt=""></a>
                                        <div class="propertiy-det-box">
                                            <h4><a href="#">Casel la Denver</a></h4>
                                            <p>Price $1,09,000</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6 single-propertiy mb-30">
                                        <a href="#"><img src="assets/images/propertes/w-propertie-03.jpg" alt=""></a>
                                        <div class="propertiy-det-box">
                                            <h4><a href="#">White Smith Casel</a></h4>
                                            <p>Price $1,03,000</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6 single-propertiy mb-30">
                                        <a href="#"><img src="assets/images/propertes/w-propertie-02.jpg" alt=""></a>
                                        <div class="propertiy-det-box">
                                            <h4><a href="#">Casel la Denver</a></h4>
                                            <p>Price $1,08,000</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-xl-9 col-12 order-lg-1 order-1">
                   
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="blog-details-warpper">
                                <div class="details-image mt-30">
                                    <img src="assets/images/propertes/property_details.jpg" alt="">
                                </div>
                                <div class="details-contents-wrap">
                                   
                                    <div class="properties-details-title mb-10">
                                        <h4>Address</h4>
                                    </div>

                                    <p class="mt-10"> IT PARK NAGPUR Go to Location </p>
                                    
                                    
                                    <div class="propertice-details pt-25">
                                        <div class="row">
                                           
                                            <div class="col-12">
                                                <div class="properties-details-title mb-10">
                                                    <h4>Condition</h4>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <strong>Areas:</strong><span> 1200 Sqrt</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-6">
                                                <div class="single-info">
                                                    <strong>Bedroom:</strong><span> 5 Bedroom</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <strong>Bathroom:</strong><span> 3 Bathroom</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <strong>Kitchen: </strong><span> 2</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <strong>Leaving room:</strong><span> 3</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <strong>Garage:</strong><span> 3</span>
                                                </div>
                                            </div>
                                            <div class="col-md-8 col-sm-6">
                                                <div class="single-info">
                                                    <strong>Address:</strong><span>   22 Aveniew Tower (5th floor) First Street, Chicago, USA</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-property-price">
                                                    <strong>Price:  $1,53,000</strong>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="propertice-details pt-25">
                                        <div class="row">
                                           
                                            <div class="col-12">
                                                <div class="properties-details-title mb-10">
                                                    <h4>Amenities</h4>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Air Conditioning</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-6">
                                                <div class="single-info">
                                                    <span>Bedding</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Balcony</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Cable TV</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Internet</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Parking</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>lift</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Home Theater</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Pool</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Dishwasher</span>
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <div class="single-info">
                                                    <span>Toaster</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="propertice-details pt-25">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="properties-details-title mb-20">
                                                            <h4>Floor Plan</h4>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="image">
                                                            <img src="assets/images/propertes/property-map.jpg" alt="">
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="col-md-6 pl-50 pl-xs-15 mt-xs-30">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="properties-details-title mb-20">
                                                            <h4>Take a Video Tour</h4>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="image-property">
                                                            <img class="image" src="assets/images/propertes/property-video.jpg" alt="">
                                                            <div class="video-box">
                                                                <a class="video-popup" href="https://www.youtube.com/watch?v=PG3ehLP4yD8"><i class="fa fa-play-circle-o"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div> -->
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
            
        </div>
    </div><!-- Featured Properites End -->  

</main>
<!--// Page Conttent -->
 
    
<!-- Footer Section Start --> 
@include('layouts.footer')
<!-- Footer Section End -->  
    
<!-- JS
============================================ -->

<!-- Map js code here -->
<script  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC3nDHy1dARR-Pa_2jjPCjvsOR4bcILYsM"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>
<!-- Map Active JS -->
<script src="assets/js/maplace-active.js"></script>
<!-- Main JS -->
<script src="assets/js/main.js"></script>

</body>

</html>