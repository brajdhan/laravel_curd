<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class UserController extends Controller
{
    public function index(){
        return view('auth.login');
    }
    
    // Lgoin 
    public function login(Request $req){
        $req->validate([
            'email'=>'required|email',
            'password'=> 'required|min:5|max:12', 
        ]);
      
        $user = User::where('email' ,'=', $req->email)->first();
        if($user){
            if(Hash::check($req->password, $user->password)){
                //if password match
                $req->session()->put('userid', $user->id);
                return redirect('admin/dashboard');
            }
            else
            {
                return back()->with('fail', 'Invalid Password');
            }
        }
        else
        {
            return back()->with('fail', 'No Account For This Mail');
        }    
    }

    public function register(){
        return view('auth.register');
    }

    //Register
    public function create(Request $req){
       
        $req->validate([
            'name'=>'required',
            'email'=>'required|email|unique:users',
            'password'=> 'required|confirmed|min:5|max:12',
            'password_confirmation'=> 'required'
        ]);

        $user = new User;
        $user->name = $req->name;
        $user->email = $req->email;
        $user->password = Hash::make($req->password);
        $query = $user->save();
        
        if($query){
            return back()->with('success', ' You Have Been Successfully registered');
        }else{
            return back()->with('fail', 'Something Went Wrong');
        }
    }

    //Show Dashboard
    public function profile()
    {
        if(session()->has('userid')){
            $user = User::where('id', '=', session('userid'))->first();
            $data=['LoggedInfo' => $user];
            return view('admin.dashboard', $data); 
        }
        else
        {
            return redirect()->route('login');
        }       
    }
    //logout
    public function logout() {
        if(session()->has('userid')){
            session()->pull('userid');
            return redirect('login'); 
        }  
    }    
}
