<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\admin\About;

class AboutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(session()->has('userid')){
            $abouts = About::all();
            $data =compact('abouts');
            return view('admin.about')->with($data);;
        }else{
            return redirect()->route('login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(session()->has('userid')){

            $url =url('/admin/about/create');
            $title = "Add About Details";
            $data = compact('url','title');
            return view('admin.about_create')->with($data);;
            
        }else{
            return redirect()->route('login');
        } 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        dd($request->all());
        $request->validate(
            [
                'image1' =>'required|mimes:png,jpg,jpeg|max:5000',
                'image1' =>'required|mimes:png,jpg,jpeg|max:5000',
                'heading' =>'required',
                'about_text' =>'required',
                'sub_text1'=>'required',
                'sub_text2'=>'required',
                'sub_text3'=>'required',
                'sub_text4'=>'required',
            ]
        );
        $abouts = About::all();
        $abouts->text1 = $request->text1;
        $abouts->text2 = $request->text2;
        $abouts->text3 = $request->text3;
        $abouts->text4 = $request->text4;
        $abouts->image = $request->file('file')->store('uploads');
        //print_r($banner->toArray());
        $banner->save();
        return redirect('admin/create');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
