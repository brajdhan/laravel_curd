<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\admin\FrontPage;
use Illuminate\Http\Request;

class FrontPageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(session()->has('userid')){
            $banners = FrontPage::all();
            $data =compact('banners');
            return view('admin.home')->with($data);
        }else{
            return redirect()->route('login');
        }  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(session()->has('userid')){

            $url =url('/admin/create');
            $title = "Add Banners";
            $data = compact('url','title');
            return view('admin.banner')->with($data);;
            
        }else{
            return redirect()->route('login');
        } 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
     {
    //     $request->validate(
    //         [
    //             'file' =>'required|mimes:png,jpg,jpeg|max:5000',
    //             'text1' =>'required|min:11|max:12',
    //             'text2' =>'required|min:30|max:33',
    //             'text3'=>'required|min:37|max:40',
    //             'text4'=>'required|min:10|max:30',
    //         ]
    //     );

    $request->validate(
        [
            'file' =>'required|mimes:png,jpg,jpeg|max:5000',
            'text1' =>'required',
            'text2' =>'required',
            'text3'=>'required',
            'text4'=>'required',
        ]
    );
        $banner = new FrontPage;
        $banner->text1 = $request->text1;
        $banner->text2 = $request->text2;
        $banner->text3 = $request->text3;
        $banner->text4 = $request->text4;
        $banner->image = $request->file('file')->store('uploads');
        //print_r($banner->toArray());
        $banner->save();
        return redirect('admin/create');    
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $banner = FrontPage::find($id);
        if(is_null($banner)){
            return redirect('admin/home');
        }else{
            $url =url('/admin/update') ."/". $id;
            $title = "Edit Banners";
            $data = compact('banner','url','title','id');
            return view('admin.banner')->with($data);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->hasFile('file')) {
            $banner = FrontPage::find($id);
            $banner->text1 = $request->text1;
            $banner->text2 = $request->text2;
            $banner->text3 = $request->text3;
            $banner->text4 = $request->text4;
            $banner->image = $request->file('file')->store('uploads');
            $banner->save();
            return redirect('admin/home');
        }else{
            $banner = FrontPage::find($id);
            $banner->text1 = $request->text1;
            $banner->text2 = $request->text2;
            $banner->text3 = $request->text3;
            $banner->text4 = $request->text4;
            $banner->save();
            return redirect('admin/home');
        }
       
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
