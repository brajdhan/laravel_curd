<?php

namespace App\Http\Controllers\admin;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        if(session()->has('userid')){
            return view('admin.dashboard');
        }else{
            return redirect()->route('login');
        } 
    }
}
