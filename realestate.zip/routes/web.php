<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\admin\FrontPageController;
use App\Http\Controllers\admin\AboutController;
use App\Http\Controllers\admin\ContactController;
use App\Http\Controllers\admin\ProjectsController;
use App\Http\Controllers\admin\GallaryController;
use App\Http\Controllers\admin\TestimonialsController;
use App\Http\Controllers\admin\SerevicesController;
use App\Http\Controllers\admin\DashboardController;
use App\Http\Controllers\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Website Route
Route::get('/',[HomeController::class,'index']);
Route::get('/about',[HomeController::class,'about']);
Route::get('/project',[HomeController::class,'project']);
Route::get('/project_details',[HomeController::class,'project_details']);
Route::get('/gallary',[HomeController::class,'gallary']);
Route::get('/contact',[HomeController::class,'contact']);

//Login and Register Route
Route::get('login',[UserController::class,'index'])->name('login');
Route::post('login',[UserController::class,'login']);
Route::get('admin/dashboard',[UserController::class,'profile'])->name('admin.dashboard');
Route::get('logout',[UserController::class,'logout'])->name('logout');



Route::get('register',[UserController::class,'register'])->name('register');
Route::post('register',[UserController::class,'create'])->name('register');


//DashboardController
//Route::get('admin/dashboard',[DashboardController::class, 'index'])->name('admin.dashboard');

//FrontPageController
Route::get('admin/home',[FrontPageController::class, 'index'])->name('admin.home');
Route::get('admin/create',[FrontPageController::class, 'create'])->name('admin.create');
Route::post('admin/create', [FrontPageController::class, 'store']);
Route::get('admin/edit/{id}',[FrontPageController::class,'edit'])->name('admin.edit');
Route::post('admin/update/{id}',[FrontPageController::class,'update'])->name('admin.update');

//AboutController
Route::get('admin/about', [AboutController::class, 'index'])->name('admin.about');
Route::get('admin/about/create',[AboutController::class, 'create'])->name('admin.about.create');
Route::post('admin/about/create', [AboutController::class, 'store']);
Route::get('admin/about/edit/{id}',[AboutController::class,'edit'])->name('admin.about.edit');
Route::post('admin/about/update/{id}',[AboutController::class,'update'])->name('admin.about.update');

//ContactController
Route::get('admin/contacts', [ContactController::class, 'index'])->name('admin.contacts');

//ProjectsController
Route::get('admin/projects', [ProjectsController::class, 'index'])->name('admin.projects');


//GallaryController
Route::get('admin/services', [SerevicesController::class, 'index'])->name('admin.services');

//GallaryController
Route::get('admin/gallary', [GallaryController::class, 'index'])->name('admin.gallary');

//AboutController
Route::get('admin/testimonials', [TestimonialsController::class, 'index'])->name('admin.testimonials');

