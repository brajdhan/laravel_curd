
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"> Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>/home">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      
        <div class="row">
            <div class="col-md-3">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Card Refresh <?php echo e($LoggedInfo->name); ?></h3>
  
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="card-refresh" data-source="widgets.html" data-source-selector="#card-refresh-content">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                  <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  The body of the card
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
              <div class="d-none" id="card-refresh-content">
                  The body of the card after card refresh
              </div>
            </div>
            <!-- /.col -->
            <div class="col-md-3">
              <div class="card card-success">
                <div class="card-header">
                  <h3 class="card-title">All together</h3>
  
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="card-refresh" data-source="widgets.html" data-source-selector="#card-refresh-content" data-load-on-init="false">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                    
                  </div>
                  <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  The body of the card
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
            <div class="col-md-3">
              <div class="card card-warning">
                <div class="card-header">
                  <h3 class="card-title">Loading state</h3>
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="card-refresh" data-source="widgets.html" data-source-selector="#card-refresh-content" data-load-on-init="false">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
                </div>
                <div class="card-body">
                  The body of the card
                </div>
                <!-- /.card-body -->
                <!-- Loading (remove the following to stop the loading)-->
                
                <!-- end loading -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
            <div class="col-md-3">
              <div class="card card-danger">
                <div class="card-header">
                  <h3 class="card-title">Loading state (dark)</h3>
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="card-refresh" data-source="widgets.html" data-source-selector="#card-refresh-content" data-load-on-init="false">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
                </div>
                <div class="card-body">
                  The body of the card
                </div>
                <!-- /.card-body -->
                <!-- Loading (remove the following to stop the loading)-->
                
                <!-- end loading -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel\realestate\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>