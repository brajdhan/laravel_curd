<!-- Header Section Start --> 
<header class="header-wrapper section">
    <div class="header-top bg-theme-two section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6">
                    <div class="header-top-info">
                        <p class="text-white">Call us -  <a href="tel:7066670100">+91 7066 670 100</a></p>
                    </div>
                </div>
                
                <div class="col-lg-6 col-md-6">
                    <div class="header-buttons">
                        <!-- <a class="header-btn btn" href="login">Login</a> -->
                        <a class="header-btn btn-border" href="register" >Register</a>
                        <a class="header-btn" href="<?php echo e(url('')); ?>/login">Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="header-section section">
        <div class="container">
            <div class="row align-items-center">

                <div class="col-lg-2 col-6">
                    <div class="header-logo">
                        <a href="<?php echo e(url('/')); ?>"><img src="assets/images/logo.png" alt=""></a>
                    </div>
                </div>

                <div class="col-lg-10 col-6">
                    <div class="header-mid_right-bar">
                        <nav class="main-menu d-lg-block d-none">
                            <ul>
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li><a href="<?php echo e(url('/')); ?>/about">About</a></li>
                                <!-- <li><a href="service">Services</a></li> -->
                                <li><a href="<?php echo e(url('/')); ?>/project">Project</a></li>
                                <li><a href="<?php echo e(url('/')); ?>/gallary">Gallary</a></li>
                                <li><a href="<?php echo e(url('/')); ?>/contact">Contact</a></li>
                            </ul>
                        </nav>
                        <div id="search-overlay-trigger" class="search-icon">
                            <a href="javascript:void(0)"><i class="fa fa-search"></i></a>
                        </div>
                    </div>
                </div>
                <!-- Mobile Menu -->
                <div class="mobile-menu order-12 d-block d-lg-none col"></div>
            </div>
        </div>
    </div>
</header>
<!-- Header Section End --><?php /**PATH E:\xampp\htdocs\Laravel\realestate\resources\views/layouts/header.blade.php ENDPATH**/ ?>