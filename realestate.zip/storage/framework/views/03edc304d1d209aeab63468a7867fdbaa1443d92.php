<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Brajdhan - Real Estate </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- CSS
	============================================ -->
   
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>


<!-- Header Section Start --> 
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header Section Start --> 


<!-- Footer Section Start --> 
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End -->  
    
    
<!-- JS
============================================ -->

<!-- Map js code here -->
<script  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC3nDHy1dARR-Pa_2jjPCjvsOR4bcILYsM"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>
<!-- Map Active JS -->
<script src="assets/js/maplace-active.js"></script>
<!-- Main JS -->
<script src="assets/js/main.js"></script>


</body>

</html><?php /**PATH E:\xampp\htdocs\Laravel\realestate\resources\views/gallary.blade.php ENDPATH**/ ?>