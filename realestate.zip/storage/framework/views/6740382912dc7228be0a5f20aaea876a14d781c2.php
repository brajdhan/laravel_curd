<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Brajdhan - Real Estate </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- CSS
	============================================ -->
   
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>


<!-- Header Section Start --> 
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header Section Start --> 


<!-- Hero Section Start -->
<div class="hero-section section">

    <div class="hero-slider hero-slider-one">
        <div class="hero-slide-item" style="background-image: url(assets/images/hero/hero-1.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-8">
                        
                        <div class="hero-content ">
                            <h1>Desilva De Villa</h1>
                            <h3 class="text-white mt-15">24 North Street, California, INDIA</h3>
                            <p>3520 sqft, 5 Bed, 3 Bath, 2 Garage</p>
                            <div class="hero-price">
                                <h2 class="text-white">For Sale $54,000</h2>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

</div><!-- Hero Section End -->

<!-- About Section Start -->
<div class="about-section section pt-65 pb-75 pt-md-55 pb-md-55 pt-sm-45 pb-sm-45 pt-xs-25 pb-xs-25">
    <div class="container">
        <div class="row align-items-center fix">
            
            <div class="col-lg-4 col-md-5 col-12 offset-lg-1 mb-15 mt-35">
                <div class="about-properties-area">
                    <div class="about-slider_bg"></div>
                    <div class="about-properties-slider">
                        <div class="about-properties-item">
                            <div class="image"><img src="assets/images/about/about-1.jpg" alt=""></div>
                        </div>

                        <div class="about-properties-item">
                            <div class="image"><img src="assets/images/about/about-2.jpg" alt=""></div>
                        </div>

                    </div>
                </div>
            </div>
            
            <div class="about-content col-lg-6 col-md-7 col-12 ml-auto mt-35 pl-lg-0">
                <h2>We never compromize <br> with quality work...</h2>
                <p>Ladwan is one of the most popular real estate company all around INDIA. You can find your dream property or build property </p>
                
                <div class="row row-25">
                    
                    <div class="about-feature col-md-6 col-sm-6 col-12 mb-35">
                        <div class="icon"><img src="assets/images/icons/feature-1.png" alt=""></div>
                        <div class="content">
                            <h4>Minimum Cost</h4>
                            <p>Privide low cost that help all more build real estate</p>
                        </div>
                    </div>
                    
                    <div class="about-feature col-md-6 col-sm-6 col-12 mb-35">
                        <div class="icon"><img src="assets/images/icons/feature-2.png" alt=""></div>
                        <div class="content">
                            <h4>Best Marketing</h4>
                            <p>Privide low cost that help all more build real estate</p>
                        </div>
                    </div>
                    
                    <div class="about-feature col-md-6 col-sm-6 col-12 mb-35">
                        <div class="icon"><img src="assets/images/icons/feature-3.png" alt=""></div>
                        <div class="content">
                            <h4>Easy to Search</h4>
                            <p>You can find your property to simply and easy way</p>
                        </div>
                    </div>
                    
                    <div class="about-feature col-md-6 col-sm-6 col-12 mb-35">
                        <div class="icon"><img src="assets/images/icons/feature-4.png" alt=""></div>
                        <div class="content">
                            <h4>Secure</h4>
                            <p>You can find your property to simply and easy way</p>
                        </div>
                    </div>
                    
                </div>
                
            </div>
            
            
        </div>
    </div>
</div><!-- About Section End -->

<!-- Featured Properites Start -->   
<div class="featured-properites-section section">
    <div class="container">
      
        <div class="row">
            <div class="section-title text-center col mb-30 mb-md-20 mb-xs-20 mb-sm-20">
                <h2> Complated Property</h2>
                <p> one of the most popular real estate company all around India. You <br> can find your dream property or build property with us</p>
            </div>
        </div>
       
        <div class="row">
           
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/01.jpg" alt="">
                        </a>
                        <!-- <span class="level-stryker">FOR RENT</span> -->
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (Propery Name)</a></h4>
                        <p>
                            <span class="location">22 First street, Nagpur, INDIA</span>
                            <span class="property-info">1200 Sqft, 3 Bed, 2 Bath, 1 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $1,25,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/02.jpg" alt="">
                        </a>
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Chandrpur (Propery Name)</a></h4>
                        <p>
                            <span class="location">132 Future Street, Nagpur, INDIA</span>
                            <span class="property-info">1600 Sqft, 4 Bed, 2 Bath, 2 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $70,250</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/03.jpg" alt="">
                        </a>
                        <!-- <span class="level-stryker-2">FOR RENT</span> -->
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (Propery Name)</a></h4>
                        <p>
                            <span class="location">1 DE Silicon Nagpur, INDIA</span>
                            <span class="property-info">1800 Sqft, 6 Bed, 4 Bath, 3 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $1,50,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/04.jpg" alt="">
                        </a>
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (Propery Name)</a></h4>
                        <p>
                            <span class="location">22 First street, Nagpur, INDIA</span>
                            <span class="property-info">1200 Sqft, 3 Bed, 2 Bath, 1 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $92,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
           
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/01.jpg" alt="">
                        </a>
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (Propery Name) </a></h4>
                        <p>
                            <span class="location">22 First street, Nagpur, INDIA</span>
                            <span class="property-info">1200 Sqft, 3 Bed, 2 Bath, 1 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $1,90,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/02.jpg" alt="">
                        </a>
                        <!-- <span class="level-stryker-2">FOR RENT</span> -->
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (Propery Name)</a></h4>
                        <p>
                            <span class="location">132 Future Street, Nagpur, INDIA</span>
                            <span class="property-info">1600 Sqft, 4 Bed, 2 Bath, 2 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $70,250</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/03.jpg" alt="">
                        </a>
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (propery name)</a></h4>
                        <p>
                            <span class="location">132 Future Street, Nagpur, INDIA</span>
                            <span class="property-info">1800 Sqft, 6 Bed, 4 Bath, 3 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $2,25,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/04.jpg" alt="">
                        </a>
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (propery name)</a></h4>
                        <p>
                            <span class="location">22 First street, Nagpur, INDIA</span>
                            <span class="property-info">1200 Sqft, 3 Bed, 2 Bath, 1 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $1,05,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
        </div>
        
    </div>
</div><!-- Featured Properites End -->  

  
<!-- Choose Section Start -->
<div class="choose-section section pt-100 pb-80 pt-md-75 pb-md-65 pt-sm-65 pb-sm-45 pt-xs-60 pb-xs-20">
    <div class="container">
        <div class="row align-items-center">
           
            <div class="col-lg-5 col-md-12 col-12">
                <div class="choose-properties">
                   
                    <div class="choose-provide">
                        
                        <span class="discount-stryker">35% Discount</span>
                        
                        <div class="image-1">
                            <img src="assets/images/propertes/choose-02.jpg" alt="">
                            <div class="price-box">
                                <p>Price $1,53,000</p>
                            </div>
                        </div>
                        <div class="image-2">
                            <img src="assets/images/propertes/choose-01.jpg" alt="">
                            <div class="price-box">
                                <p>Price $89,000</p>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            
            <div class="about-content col-lg-7 col-md-12 col-12 ">
                <h2>We never compromize <br> with quality work...</h2>
                <p>Ladwan is one of the most popular real estate company all around INDIA. You can find your dream property or build property </p>
                
                <div class="row row-25">
                    
                    <div class="about-feature col-md-6 col-sm-12 col-12 mb-35">
                        <div class="icon"><img src="assets/images/icons/feature-5.png" alt=""></div>
                        <div class="content-two">
                            <h4>Royel touch paint</h4>
                            <p>Paint is the mirron of beautifull house build property with us </p>
                        </div>
                    </div>
                    
                    <div class="about-feature col-md-6  col-sm-12 col-12 mb-35">
                        <div class="icon"><img src="assets/images/icons/feature-6.png" alt=""></div>
                        <div class="content-two">
                            <h4>Fully Furnished</h4>
                            <p>Well decorated and fully fuhed properties is available for all</p>
                        </div>
                    </div>
                    
                    <div class="about-feature col-md-6 col-sm-12 col-12 mb-35">
                        <div class="icon"><img src="assets/images/icons/feature-7.png" alt=""></div>
                        <div class="content-two">
                            <h4>Latest Interior design</h4>
                            <p>All interior are latest and luxus mirron of beauty dream </p>
                        </div>
                    </div>
                    
                    <div class="about-feature col-md-6 col-sm-12 col-12 mb-35">
                        <div class="icon"><img src="assets/images/icons/feature-8.png" alt=""></div>
                        <div class="content-two">
                            <h4>Non stop security</h4>
                            <p>Security in our property area is the main priority for our all</p>
                        </div>
                    </div>
                    
                </div>
                
            </div>
            
            
        </div>
    </div>
</div><!-- Choose Section End -->
 
<!-- Featured Properites Start -->   
<div class="featured-properites-section section">
    <div class="container">
      
        <div class="row">
            <div class="section-title text-center col mb-30 mb-md-20 mb-xs-20 mb-sm-20">
                <h2> Upcoming Property</h2>
                <p> one of the most popular real estate company all around INDIA. You <br> can find your dream property or build property with us</p>
            </div>
        </div>
       
        <div class="row">
           
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/01.jpg" alt="">
                        </a>
                        <!-- <span class="level-stryker">FOR RENT</span> -->
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (Propery Name) </a></h4>
                        <p>
                            <span class="location">22 First street, Nagpur, INDIA</span>
                            <span class="property-info">1200 Sqft, 3 Bed, 2 Bath, 1 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $ 1,59,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/02.jpg" alt="">
                        </a>
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur (ProperyName)</a></h4>
                        <p>
                            <span class="location">132 Future Street, Nagpur, INDIA</span>
                            <span class="property-info">1600 Sqft, 4 Bed, 2 Bath, 2 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $ 1,59,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/03.jpg" alt="">
                        </a>
                        <!-- <span class="level-stryker-2">FOR RENT</span> -->
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur Villa</a></h4>
                        <p>
                            <span class="location">1 DE Silicon Nagpur, Denver</span>
                            <span class="property-info">1800 Sqft, 6 Bed, 4 Bath, 3 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Price $2,32,000</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
            <div class="col-lg-3 col-md-6 col-12">
                <!-- single-property Start -->
                <div class="single-property mt-30">
                    <div class="property-img">
                        <a href="project-details">
                            <img src="assets/images/propertes/04.jpg" alt="">
                        </a>
                    </div>
                    <div class="property-desc">
                        <h4><a href="project-details">Nagpur Villa</a></h4>
                        <p>
                            <span class="location">22 First street, Nagpur, INDIA</span>
                            <span class="property-info">1200 Sqft, 3 Bed, 2 Bath, 1 Garage </span>
                        </p>
                        <!-- <div class="price-box">
                            <p>Rent $32,00/m</p>
                        </div> -->
                    </div>
                </div><!-- single-property End -->
            </div>
            
        </div>
        
    </div>
</div>
<!-- Featured Properites End -->  
 
<!-- Ladwan Banner Area Start-->
<div class="ortiz-banner-area section pt-110 pt-md-90 pt-sm-70 pt-xs-60">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="banner-inner-box">
                    <img src="assets/images/banner/banner-01.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Ladwan Banner Area End-->
  
   
<!-- Our Agents Section Start -->    
<!-- <div class="our-agents-section section pt-110 pt-md-90 pt-sm-70 pt-xs-60 pb-110 pb-md-40 pb-sm-40 pb-xs-20">
    <div class="container">
       
        <div class="row">
            <div class="section-title text-center col mb-30 mb-md-20 mb-xs-20 mb-sm-20">
                <h2>Our Agents</h2>
                <p>  one of the most popular real estate company all around INDIA. You 
                <br> can find your dream property or build property with us</p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-3 col-md-6 mt-30">
                <!- Our Agents Start ->
                <div class="our-agents">
                    <div class="agents-image">
                        <img src="assets/images/agents/agents-01.jpg" alt="">
                        
                        <div class="agents-info">
                            <h3>View Details</h3>
                            <div class="agents-social">
                                <ul>
                                    <li><a href="https://www.skype.com/en/"><i class="fa fa-skype"></i></a></li>
                                    <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                    <div class="agents-contents">
                        <h4>Jassica Thomson</h4>
                        <p>Real Estate Agent</p>
                    </div>
                </div><!- Our Agents End ->
            </div>
            
            <div class="col-lg-3 col-md-6 mt-30">
                <!- Our Agents Start ->
                <div class="our-agents">
                    <div class="agents-image">
                        <img src="assets/images/agents/agents-06.jpg" alt="">
                        
                        <div class="agents-info">
                            <h3>View Details</h3>
                            <div class="agents-social">
                                <ul>
                                    <li><a href="https://www.skype.com/en/"><i class="fa fa-skype"></i></a></li>
                                    <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                    <div class="agents-contents">
                        <h4>Thomas Eilliams</h4>
                        <p>Real Estate Agent</p>
                    </div>
                </div><!- Our Agents End ->
            </div>
            
            <div class="col-lg-3 col-md-6 mt-30">
                <!- Our Agents Start ->
                <div class="our-agents">
                    <div class="agents-image">
                        <img src="assets/images/agents/agents-03.jpg" alt="">
                        
                        <div class="agents-info">
                            <h3>View Details</h3>
                            <div class="agents-social">
                                <ul>
                                    <li><a href="https://www.skype.com/en/"><i class="fa fa-skype"></i></a></li>
                                    <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                    <div class="agents-contents">
                        <h4>Sayana Sarlin</h4>
                        <p>Real Estate Agent</p>
                    </div>
                </div><!- Our Agents End ->
            </div>
            
            <div class="col-lg-3 col-md-6 mt-30">
                <!- Our Agents Start ->
                <div class="our-agents">
                    <div class="agents-image">
                        <img src="assets/images/agents/agents-04.jpg" alt="">
                        
                        <div class="agents-info">
                            <h3>View Details</h3>
                            <div class="agents-social">
                                <ul>
                                    <li><a href="https://www.skype.com/en/"><i class="fa fa-skype"></i></a></li>
                                    <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                    <div class="agents-contents">
                        <h4>Kuddus Boyati</h4>
                        <p>Real Estate Agent</p>
                    </div>
                </div><!- Our Agents End ->
            </div>
            
        </div>
        
    </div>
    
</div> -->
<!-- Our Agents Section End     -->
   
   
<!-- Testimonial Section Start -->
<div class="testimonial-section section pt-90 pt-md-70 pt-xs-60 pt-sm-70 pb-110 pb-110 pb-md-90 pb-sm-70 pb-xs-60 mt-50 mb-50 testimonial-bg">
    <div class="container">
        <div class="row testimonial-slider section-mb-inner">
            <div class="col-lg-6">
                <div class="single-testimonial">
                    <div class="testimonial-author">
                        <div class="image">
                            <img src="assets/images/testimonial/outher-01.jpg" alt="">
                        </div>
                        <div class="outhor-info">
                            <h4>Rashmi</h4>
                            <p>CEO, Ladwan Group</p>
                        </div>
                    </div>
                    <div class="testimonial-dec">
                        <p>one of the most popular real estate company all around INDIA. You can find your dream property or the build erty with us. We always provide importance</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="single-testimonial">
                    <div class="testimonial-author">
                        <div class="image">
                            <img src="assets/images/testimonial/outher-02.jpg" alt="">
                        </div>
                        <div class="outhor-info">
                            <h4>Rashmi</h4>
                            <p>CEO, Ladwan Group</p>
                        </div>
                    </div>
                    <div class="testimonial-dec">
                        <p>one of the most popular real estate company all around INDIA. You can find your dream property or the build erty with us. We always provide importance</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="single-testimonial">
                    <div class="testimonial-author">
                        <div class="image">
                            <img src="assets/images/testimonial/outher-01.jpg" alt="">
                        </div>
                        <div class="outhor-info">
                            <h4>Lora Momen Smith</h4>
                            <p>CEO, Momens Group</p>
                        </div>
                    </div>
                    <div class="testimonial-dec">
                        <p>Ladwan is one of the most popular real estate company all around INDIA. You can find your dream property or the build erty with us. We always provide importance</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- Testimonial Section End -->


    
<!-- Footer Section Start --> 
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End -->  
    
    
<!-- JS
============================================ -->

<!-- Map js code here -->
<script  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC3nDHy1dARR-Pa_2jjPCjvsOR4bcILYsM"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>
<!-- Map Active JS -->
<script src="assets/js/maplace-active.js"></script>
<!-- Main JS -->
<script src="assets/js/main.js"></script>


</body>

</html><?php /**PATH E:\xampp\htdocs\Laravel\realestate\resources\views/home.blade.php ENDPATH**/ ?>