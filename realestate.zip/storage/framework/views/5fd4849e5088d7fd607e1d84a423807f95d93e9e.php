<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Contact || Brajdhan - Real Estate </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- CSS
	============================================ -->
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
</head>

<body>

<!-- Header Section Start -->
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header Section End -->


<!-- Breadcrumb -->
<div class="breadcrumb-area section" style="background-image: url(assets/images/bg/breadcrumb.jpg)">
    <div class="container">
        <div class="breadcrumb pt-75 pb-75 pt-sm-70 pb-sm-40 pt-xs-70 pb-xs-40">
            <div class="row">
                <div class="col">
                    <h2>Contact us</h2>
                    <!-- breadcrumb-list start -->
                    <ul class="breadcrumb-list">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active">Contact</li>
                    </ul>
                    <!-- breadcrumb-list end -->
                </div>
            </div>
        </div>
    </div>
</div>
<!--// Breadcrumb -->
 
   
<!-- Our Agents Section Start -->    
<div class="contact-section section pt-110 pt-md-90 pt-sm-70 pt-xs-60 pb-110 pb-md-90 pb-sm-70 pb-xs-60">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="contact-us-wrap">
                    <div class="contact-title pb-30">
                        <h4>GET IN <span>TOUCH</span></h4>
                        <p>Ladwan is the best theme for  elit, sed do eiusmod tempor dolor sit ame  tse ctetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et lorna aliquatd minim veniam, quis nostrud exercitation oris nisi </p>
                    </div>
                    
                    <div class="contact-info">
                        <ul>
                            <li>
                                <div class="contact-text d-flex align-items-center">
                                    <i class="glyph-icon flaticon-placeholder"></i> 
                                    <p>256, 1st Gaytri NAgar, IT PARK  <br> Nagpur India</p>
                                </div>
                            </li>
                            <li>
                                <div class="contact-text d-flex align-items-center">
                                    <i class="glyph-icon flaticon-call"></i> 
                                    <p>
                                    <span>Telephone : <a href="tel:7066670100"> +91 7066 670 100</a></span>
                                            <span>Telephone : <a href="tel:7066670100"> +91 7066 670 100</a></span>
                                    </p>
                                </div>
                            </li>
                            <li>
                                <div class="contact-text d-flex align-items-center">
                                    <i class="glyph-icon flaticon-earth"></i>
                                    <p>
                                    <span>Email : <a href="mailto:info@example.com">info@ladwanrealested.com</a></span>
                                    <span>Web : <a href="https://hasthemes.com/">www.ladwanrealested.com</a></span>
                                    </p>
                                </div>
                            </li>
                        </ul>
                    </div>   
                </div>
            </div>
            <div class="col-lg-6">
                <div class="contact-us-wrap">
                    <h4>Leave a Message</h4>
                       
                     <div class="contact-form">
                        <form id="contact-form" action="assets/php/mail.php">
                            <div class="row row-10">
                                <div class="col-md-6 col-12 mb-30"><input  name="name" type="text" placeholder="Your Name"></div>
                                <div class="col-md-6 col-12 mb-30"><input  name="email" type="email" placeholder="Email"></div>
                                <div class="col-12 mb-30"><textarea name="message"  placeholder="Message"></textarea></div>
                                <div class="col-12"><button class="btn send-btn btn-circle">Send</button></div>
                            </div>
                        </form>
                        <p class="form-messege"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div><!-- Our Agents Section End -->  

<div class="embed-responsive">
<div class="mapouter"><div class="gmap_canvas"><iframe  id="gmap_canvas" src="https://maps.google.com/maps?q=RS%20Software%20Nagpur&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org"></a><br><style>.mapouter{position:relative;text-align:right;}</style><a href="https://www.embedgooglemap.net">google maps embedded map</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:600px;}</style></div></div>
</div>
 
 
<!-- Footer Section Start --> 
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer Section End -->  
    
    

<!-- JS
============================================ -->

<!-- Map js code here -->
<!-- <script  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC3nDHy1dARR-Pa_2jjPCjvsOR4bcILYsM"></script> -->
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>
<!-- Map Active JS -->
<script src="assets/js/maplace-active.js"></script>
<!-- Main JS -->
<script src="assets/js/main.js"></script>

</body>

</html><?php /**PATH E:\xampp\htdocs\Laravel\realestate\resources\views/contact.blade.php ENDPATH**/ ?>