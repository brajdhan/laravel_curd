
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Home</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('')); ?>/create">Home</a></li>
              <li class="breadcrumb-item active">Home</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <form action="<?php echo e($url); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          
          <!-- SELECT2 EXAMPLE -->
          <div class="card card-default">
            <div class="card-header">
              <h3 class="card-title"><?php echo e($title); ?></h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-card-widget="remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                    <label>Heading</label>
                    <input type="text" name="heading" class="form-control" value="<?php if(isset($id)): ?>
                    <?php echo e($banner->heading); ?>  <?php endif; ?> <?php echo e(old('heading')); ?> ">
                    <small id="helpId" class=" text-danger">
                        <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                       
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                    <label>About Text</label>
                    <input type="text" name="about_text" class="form-control" value="<?php echo e(old('about_text')); ?> <?php if(isset($id)): ?>
                    <?php echo e($banner->about_text); ?>  <?php endif; ?> ">
                    <small id="helpId" class=" text-danger">
                        <?php $__errorArgs = ['about_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                  </div>
                  <!-- /.form-group -->
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                    <label> Sub Text 1</label>
                    <input type="text" name="sub_text1" class="form-control" value="<?php if(isset($id)): ?>
                    <?php echo e($banner->sub_text1); ?>  <?php endif; ?> <?php echo e(old('sub_text1')); ?> ">
                    <small id="helpId" class=" text-danger">
                        <?php $__errorArgs = ['sub_text1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                       
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                    <label> Sub Text 2</label>
                    <input type="text" name="sub_text2" class="form-control" value="<?php echo e(old('sub_text2')); ?> <?php if(isset($id)): ?>
                    <?php echo e($banner->sub_text2); ?>  <?php endif; ?> ">
                    <small id="helpId" class=" text-danger">
                        <?php $__errorArgs = ['sub_text2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- /.col -->
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Sub Text 3</label>
                    <input type="text" name="sub_text3" class="form-control" value="<?php echo e(old('sub_text3')); ?> <?php if(isset($id)): ?>
                    <?php echo e($banner->sub_text3); ?>  <?php endif; ?> ">
                    <small id="helpId" class=" text-danger">
                        <?php $__errorArgs = ['sub_text3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                    <label> Sub Text 4</label>
                    <input type="text" name="sub_text4" class="form-control" value="<?php echo e(old('sub_text4')); ?> <?php if(isset($id)): ?>
                    <?php echo e($banner->sub_text4); ?>  <?php endif; ?> ">
                    <small id="helpId" class=" text-danger">
                        <?php $__errorArgs = ['sub_text4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- /.col -->

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="">Image1</label>
                        <input type="file" name="image1" class="form-control">
                        <small id="helpId" class="text-danger">
                            <?php $__errorArgs = ['image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </small>
                      </div>

                      <div class="form-group">
                        <label for="">Image2</label>
                        <input type="file" name="image2" class="form-control">
                        <small id="helpId" class=" text-danger">
                            <?php $__errorArgs = ['image2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </small>
                      </div>
                </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <button class="btn btn-primary">Submit</button>
            </div>
          </div>
          <!-- /.card -->
      </form>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel\realestate\resources\views/admin/about_create.blade.php ENDPATH**/ ?>