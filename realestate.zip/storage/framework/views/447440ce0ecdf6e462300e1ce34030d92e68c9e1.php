<footer class="footer-section section ">
   
    <div class="footer-top footer-bg pt-70 pt-md-50 pt-sm-30 pt-xs-20 pb-100 pb-md-90 pb-sm-70 pb-xs-60">
        <div class="container">
           <div class="row">
                <div class="col-coustom-3 col-md-6 col-lg-3 col-12 mt-40">
                    <!-- Footer-widget Start -->
                    <div class="footer-widget">
                        <div class="footer-title">
                            <h3>About</h3>
                        </div>
                        <div class="footer-info">
                            <p>Ladwan is the best and popular real estate to you how all this mistaolt cing pleasure and praising ained wasnad pain was prexplain</p>
                            <div class="newsletter-box">
                                
                                <form id="mc-form" class="mc-form footer-newsletter" >
                                    <input id="mc-email" type="email" autocomplete="off" placeholder="Email for Newsletter" />
                                    <button id="mc-submit"><i class="fa fa-paper-plane"></i></button>
                                </form>
                            </div>
                            
                            <!-- mailchimp-alerts Start -->
                            <div class="mailchimp-alerts text-centre">
                                <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                                <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                            </div><!-- mailchimp-alerts end -->
                        </div>   
                    </div><!-- Footer-widget End -->
                </div>
                <div class="col-coustom-3 col-md-6 col-lg-3 col-12 mt-40">
                    <!-- Footer-widget Start -->
                    <div class="footer-widget">
                        <div class="footer-title">
                            <h3>Popular Post</h3>
                        </div>
                        <div class="footer-info">
                            <div class="single-list">
                                <h4>Duplex Villa Design</h4>
                                <p>Lorem ipsum dolor sit amet, tur acinglit sed do eius </p>
                            </div>
                            <div class="single-list">
                                <h4>Duplex Villa Design</h4>
                                <p>Lorem ipsum dolor sit amet, tur acinglit sed do eius </p>
                            </div>
                        </div>   
                    </div><!-- Footer-widget End -->
                </div>
                <div class="col-coustom-3 col-md-6 col-lg-3 col-12 mt-40">
                    <!-- Footer-widget Start -->
                    <div class="footer-widget">
                        <div class="footer-title">
                            <h3>Quick Link</h3>
                        </div>
                        <div class="footer-info">
                            <ul class="footer-list">
                                <li><a href="/">Home</a></li>
                                <li><a href="about">About</a></li>
                                <li><a href="service">Sercives</a></li>
                                <li><a href="project">Project</a></li>
                                <li><a href="gallary">Gallary</a></li>
                                <li><a href="contact">Contact</a></li>
                            </ul>
                        </div>   
                    </div><!-- Footer-widget End -->
                </div>
                <div class="col-coustom-3 col-md-6 col-lg-3 col-12 mt-40">
                    <!-- Footer-widget Start -->
                    <div class="footer-widget">
                        <div class="footer-title">
                            <h3>Contact Us</h3>
                        </div>
                        <div class="footer-info">
                            <ul class="footer-list">
                                <li>
                                    <div class="contact-text">
                                        <i class="glyph-icon flaticon-placeholder"></i> 
                                        <p>256, 1st Gaytri NAgar, IT PARK  <br> Nagpur India</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="contact-text">
                                        <i class="glyph-icon flaticon-call"></i> 
                                        <p>
                                            <span>Telephone : <a href="tel:7066670100"> +91 7066 670 100</a></span>
                                            <span>Telephone : <a href="tel:7066670100"> +91 7066 670 100</a></span>
                                        </p>
                                        
                                    </div>
                                </li>
                                <li>
                                    <div class="contact-text">
                                        <i class="glyph-icon flaticon-earth"></i>
                                        <p>
                                            <span>Email : <a href="mailto:info@example.com">info@ladwanrealested.com</a></span>
                                            <span>Web : <a href="https://hasthemes.com/">www.ladwanrealested.com</a></span>
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>   
                    </div><!-- Footer-widget End -->
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; RS Software. <a href="https://rssoftware.in/">All rights reserved.</a> </p>
                </div>
            </div>
        </div>
    </div>
    
</footer><?php /**PATH E:\xampp\htdocs\Laravel\realestate\resources\views/layouts/footer.blade.php ENDPATH**/ ?>