
<?php $__env->startPush('title'); ?>
<title>Courses</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
<h1 class="text-center">Courses Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\ProjectLara\resources\views/courses.blade.php ENDPATH**/ ?>