
<?php $__env->startPush('title'); ?>
<title>Customer Details</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
<div class="container">
    <div class="row m-auto pt-5">
        <div class="col-md-12 m-auto">
            <a href="<?php echo e(route('customer.create')); ?>">
                <button class="btn btn-primary d-inline-block m-2 float-right">Add</button>
            </a>
            <!-- <?php echo e(print_r($customers)); ?> -->
            <table class="table">
                <thead>
                    <tr>
                        <th>Sr No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>State</th>
                        <th>Country</th>
                        <th>DOB</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($customer->costomers_id); ?></td>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td>
                            <?php if($customer->gender =='M'): ?>
                                Male
                            <?php elseif($customer->gender =='F'): ?>
                                Female 
                            <?php else: ?>
                                Other
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($customer->state); ?></td>
                        <td><?php echo e($customer->country); ?></td>
                         <td>
                             <!-- with helper autoload file -->
                             <!--<?php echo e(get_formated_date($customer->dob, 'd-M-Y')); ?> -->
                             <?php echo e($customer->dob); ?>


                        </td>
                        <td>
                            <?php if($customer->status=='1'): ?>
                                <span class="badge badge-success p-1">Active</span>
                            <?php else: ?>
                                 <span class="badge badge-danger p-1">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('/customer/edit/')); ?>/<?php echo e($customer->costomers_id); ?>" class="badge badge-primary">Edit</a>
                            <a href="<?php echo e(route('customer.edit',['id'=>$customer->costomers_id])); ?>" class="badge badge-primary">Edit</a>
                            <a href="<?php echo e(url('/customer/delete/')); ?>/<?php echo e($customer->costomers_id); ?>" class="badge badge-danger">Delete</a>
                            <a href="<?php echo e(route('customer.delete',['id'=>$customer->costomers_id])); ?>" class="badge badge-danger">Route link Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\ProjectLara\resources\views//customer-view.blade.php ENDPATH**/ ?>