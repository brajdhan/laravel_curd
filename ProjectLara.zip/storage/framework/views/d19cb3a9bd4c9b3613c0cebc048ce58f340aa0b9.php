
<?php $__env->startPush('title'); ?>
<title>Customer</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
<!-- single -->
<!-- <form action="<?php echo e(url('/')); ?>/customer" method="post"> -->
<form action="<?php echo e($url); ?>" method="post" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>
        <div class="container mt-4 card p-3 bg-white">
            <h3 class="text-center txt-primary">
                <?php echo e($title); ?>

            </h3>
            <div class="row">
              <div class="form-group">
                <label for="">Upload File</label>
                <input type="file" name="file" class="form-control form-control-file" name="" id="" placeholder="" aria-describedby="fileHelpId">
                <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
              </div>
            </div>
            <div class="row">

                <div class="form-group col-md-6 required">
                  <label for="">Name</label>
                  
                  <input type="text" name="name" class="form-control" value=" <?php echo e(old('name')); ?> <?php if(isset($id)): ?>
                  <?php echo e($customer->name); ?>  <?php endif; ?> ">
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Email</label>
                  <!--   -->
                  <input type="email" name="email" class="form-control" value=" <?php echo e(old('email')); ?> <?php if(isset($id)): ?>
                  <?php echo e($customer->email); ?>  <?php endif; ?> ">
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Password</label>
                  <input type="password" name="password" class="form-control">
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Confirm Password</label>
                  <input type="password" name="password_confirmation" class="form-control">
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Country</label>
                  <!--  -->
                  <input type="text" name="country" class="form-control" value="<?php echo e(old('country')); ?> <?php if(isset($id)): ?>
                  <?php echo e($customer->country); ?>  <?php endif; ?> ">
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">State</label>
                  <!--  -->
                  <input type="text" name="state" class="form-control" value="<?php echo e(old('state')); ?> <?php if(isset($id)): ?>
                  <?php echo e($customer->state); ?>  <?php endif; ?> ">
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>
                <div class="form-group col-md-12 required">
                  <label for="">Address</label>
                  <textarea name="address" class="form-control" cols="30" rows="3"><?php echo e(old('address')); ?> <?php if(isset($id)): ?>
                  <?php echo e($customer->address); ?>  <?php endif; ?> </textarea>
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Gender</label><br>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="M"
                    <?php if(isset($id)): ?>  <?php echo e($customer->gender == "M" ? "checked" : ""); ?>  <?php endif; ?>                  
                    />
                    <label for="" class="form-check-input" > Male</label>
                  </div>


                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="F" 
                    <?php if(isset($id)): ?>  <?php echo e($customer->gender == "F" ? "checked" : ""); ?>  <?php endif; ?> 
                    />
                    <label for="" class="form-check-input" >Female</label>
                  </div>
                 
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="O" 
                    <?php if(isset($id)): ?>  <?php echo e($customer->gender == "O" ? "checked" : ""); ?>  <?php endif; ?> 
                    />
                    <label for="" class="form-check-input" >Other</label>
                  </div>
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>

                <div class="form-group col-md-6 required">
                  <label for="">Date Of Birth</label>
                  <input type="date" name="dob" class="form-control"value="<?php echo e(old('dob')); ?> <?php if(isset($id)): ?>  <?php echo e($customer->dob); ?>  <?php endif; ?>">
                  <small id="helpId" class="text-danger">
                      <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </small>
                </div>
              
                <div class="col-md-6 required">
                <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\ProjectLara\resources\views/customer.blade.php ENDPATH**/ ?>