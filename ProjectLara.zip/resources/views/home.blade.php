@extends('layouts.main')
@push('title')
<title>Home</title>
@endpush
@section('main-section')
<h1 class="text-center">HomePAge</h1>
@endsection