@extends('layouts.main')
@push('title')
<title>Courses</title>
@endpush
@section('main-section')
<h1 class="text-center">Courses Page</h1>
@endsection