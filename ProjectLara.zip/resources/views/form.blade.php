@extends('layouts.main')
@push('title')
<title>Form</title>
@endpush
@section('main-section')
<h1 class="text-center">form Page</h1>

<form action="{{url('/')}}/register" method="POST">
    @csrf
    @php

    @endphp
    <div class="form-group">
        <label for="">Name</label>
        <input type="text" name="name" class="form-control" value="{{old('name')}}">
        <small id="helpId" class="text-danger">
            @error('name') 
                {{$message}}
            @enderror
        </small> 
    </div>

    <div class="form-group">
        <label for="">Email</label>
        <input type="text" name="email" class="form-control" value="{{old('email')}}">
        <small id="helpId" class="text-danger">
            @error('email') 
                {{$message}}
            @enderror
        </small> 
    </div>

    <div class="form-group">
        <label for="">Password</label>
        <input type="text" name="password" class="form-control">
        <small id="helpId" class="text-danger">
            @error('password') 
                {{$message}}
            @enderror
        </small>
    </div>

    
    <div class="form-group">
        <label for="">Confirm Password</label>
        <input type="text" name="password_confirmaion" class="form-control" placeholder="" aria-describedby="helpId">
        <small id="helpId" class="text-danger">
            @error('confirm_password') 
                {{$message}}
            @enderror
        </small> 
    </div>
    <button class="btn btn-primary">Submit</button>
</form>
@endsection