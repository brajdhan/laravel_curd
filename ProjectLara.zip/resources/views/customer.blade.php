@extends('layouts.main')
@push('title')
<title>Customer</title>
@endpush
@section('main-section')
<!-- single -->
<!-- <form action="{{url('/')}}/customer" method="post"> -->
<form action="{{$url}}" method="post" enctype="multipart/form-data"> 
        @csrf
        <div class="container mt-4 card p-3 bg-white">
            <h3 class="text-center txt-primary">
                {{$title}}
            </h3>
            <div class="row">
              <div class="form-group">
                <label for="">Upload File</label>
                <input type="file" name="file" class="form-control form-control-file" name="" id="" placeholder="" aria-describedby="fileHelpId">
                <small id="helpId" class="text-danger">
                      @error('file')
                      {{$message}}
                      @enderror
                  </small>
              </div>
            </div>
            <div class="row">

                <div class="form-group col-md-6 required">
                  <label for="">Name</label>
                  
                  <input type="text" name="name" class="form-control" value=" {{old('name')}} @isset($id)
                  {{$customer->name}}  @endisset ">
                  <small id="helpId" class="text-danger">
                      @error('name')
                      {{$message}}
                      @enderror
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Email</label>
                  <!--   -->
                  <input type="email" name="email" class="form-control" value=" {{old('email')}} @isset($id)
                  {{$customer->email}}  @endisset ">
                  <small id="helpId" class="text-danger">
                      @error('email')
                      {{$message}}
                      @enderror
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Password</label>
                  <input type="password" name="password" class="form-control">
                  <small id="helpId" class="text-danger">
                      @error('password')
                      {{$message}}
                      @enderror
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Confirm Password</label>
                  <input type="password" name="password_confirmation" class="form-control">
                  <small id="helpId" class="text-danger">
                      @error('password_confirmation')
                      {{$message}}
                      @enderror
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Country</label>
                  <!--  -->
                  <input type="text" name="country" class="form-control" value="{{ old('country') }} @isset($id)
                  {{$customer->country}}  @endisset ">
                  <small id="helpId" class="text-danger">
                      @error('country')
                      {{$message}}
                      @enderror
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">State</label>
                  <!--  -->
                  <input type="text" name="state" class="form-control" value="{{old('state')}} @isset($id)
                  {{$customer->state}}  @endisset ">
                  <small id="helpId" class="text-danger">
                      @error('state')
                      {{$message}}
                      @enderror
                  </small>
                </div>
                <div class="form-group col-md-12 required">
                  <label for="">Address</label>
                  <textarea name="address" class="form-control" cols="30" rows="3">{{old('address')}} @isset($id)
                  {{$customer->address}}  @endisset </textarea>
                  <small id="helpId" class="text-danger">
                      @error('address')
                      {{$message}}
                      @enderror
                  </small>
                </div>
                <div class="form-group col-md-6 required">
                  <label for="">Gender</label><br>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="M"
                    @isset($id)  {{$customer->gender == "M" ? "checked" : "" }}  @endisset                  
                    />
                    <label for="" class="form-check-input" > Male</label>
                  </div>


                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="F" 
                    @isset($id)  {{$customer->gender == "F" ? "checked" : "" }}  @endisset 
                    />
                    <label for="" class="form-check-input" >Female</label>
                  </div>
                 
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="O" 
                    @isset($id)  {{$customer->gender == "O" ? "checked" : "" }}  @endisset 
                    />
                    <label for="" class="form-check-input" >Other</label>
                  </div>
                  <small id="helpId" class="text-danger">
                      @error('gender')
                      {{$message}}
                      @enderror
                  </small>
                </div>

                <div class="form-group col-md-6 required">
                  <label for="">Date Of Birth</label>
                  <input type="date" name="dob" class="form-control"value="{{old('dob')}} @isset($id)  {{$customer->dob}}  @endisset">
                  <small id="helpId" class="text-danger">
                      @error('dob') {{$message}}  @enderror
                  </small>
                </div>
              
                <div class="col-md-6 required">
                <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </form>
@endsection