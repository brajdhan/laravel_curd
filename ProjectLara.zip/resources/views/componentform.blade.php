@extends('layouts.main')
@push('title')
<title>Component Data</title>
@endpush
@section('main-section')
<h1 class="text-center">Component Page</h1>

<form action="{{url('/')}}/componentform" method="POST">
    @csrf
    @php
    $demo = 1;
    @endphp
    <!-- php artisan make:component Input -->
    <div class="container">
        <x-input type="name" name="name" label="Name" :demo=$demo/>
        <x-input type="email" name="email" label="Email"/>
        <x-input type="password" name="password" label="Password"/>
        <x-input type="password" name="password_confirmaion" label="Password Confirm"/>
       
        <button class="btn btn-primary">Submit</button>
    </div>





</form>
@endsection