<?php 
//Important fvunction

//echo "Hello brajdhan";
if(!function_exists('brajdhan')){
    function brajdhan($data){
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}

if(!function_exists('get_formated_date')){
    function get_formated_date($date, $format){
        $formattedDate = date($format, strtotime($date));
        return $formattedDate;
    }
}