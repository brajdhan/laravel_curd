<?php

namespace App\Http\Controllers;
use App\Models\Employee;
use Illuminate\Http\Request;
use PhpParser\Node\Expr\Empty_;
use Symfony\Component\HttpKernel\HttpCache\ResponseCacheStrategy;

class EmployeeCotroller extends Controller
{
    //get all data
    public function getEmp()
    {
        return response()->json(Employee::all(),200);
    }
    
    //get specific data
    public function  getEmpSpecific($id)
    {
        $emp = Employee::find($id);
        if(is_null($emp)){
            return response()->json(['message'=> 'Employee not found'], 404);
        }else{
            return response()->json($emp::find($id),200);
        }
    }
    
    //add emp
    public function addEmployee(Request $request)
    {
        // $emp = new Employee();
        // $emp->name = $request['name'];
        // $emp->email = $request['email'];
        // $emp->salary = $request['salary'];
        // $emp->save();

        $emp = Employee::create($request->all());
        return response($emp,201);
    }

    //update emp
    public function updateEmp(Request $request, $id)
    {
        $emp = Employee::find($id);
        if(is_null($emp)){
            return response()->json(['message'=> 'Employee not found'], 404);
        }
        $emp->update($request->all());
            return response($emp,201);
    }

    //delte emp
    public function delData($id)
    {
        $emp = Employee::find($id);
        if(is_null($emp)){
            return response()->json(['message'=> 'Employee not found'], 404);   
        }
        $emp->delete();
        return response()->json(null, 204);
    }
}
