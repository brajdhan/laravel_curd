<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function create()
    {
        $url =url('/customer');
        $title = "Customer Registration";
        $data = compact('url','title');
        return view('customer')->with($data);
    }
    public function store(Request $req)
    {
        //brajdhan($req->all());
        //die;
        $req->validate(
            [
                'file' => 'required',
                'name' => 'required',
                'email' => 'required|email|unique:costomers',
                'password'=>'required|confirmed',
                'password_confirmation'=>'required',
                'gender' => 'required',
                'state' => 'required',
                'country' => 'required',
                'dob' => 'required',
                'address' => 'required',
            ]
            
        );
        $customers = Customer::all();
        //print_r($customers->toArray());
        //echo "<pre>";
        //print_r($req->all());
        
        $cust = new Customer;
        $cust->profile = $req->file('file')->store('uploads');
        $cust->name = $req->name;
        $cust->email = $req->email;
        $cust->gender = $req->gender;
        $cust->address = $req->address;
        $cust->state = $req->state;
        $cust->country = $req->country;
        $cust->dob = $req->dob;
        $cust->password = md5($req->password);
        //print_r($cust->toArray());
        $cust->save();
        return redirect('customer');
    }

    public function view(){
        $customers = Customer::all();
        $data =compact('customers');
        return view('/customer-view')->with($data);
    }

    public function delete($id){
        $customers = Customer::find($id);
        if(!is_null($customers)){
            $customers->delete();
        }
        return redirect('customer');
        // print_r($customers);
    }
    public function edit($id)
    {
        $customer = Customer::find($id);
        if(is_null($customer)){
            return redirect('customer');
        }else{
            $url =url('/customer/update') ."/". $id;

            $title = "Update Customer";
            $data = compact('customer','url','title','id');
            return view('customer')->with($data);
        }
    }

    public function update(Request $req, $id)
    {
        $cust = Customer::find($id);
        $cust->name = $req['name'];
        $cust->email = $req['email'];
        $cust->gender = $req['gender'];
        $cust->address = $req['address'];
        $cust->state = $req['state'];
        $cust->country = $req['country'];
        $cust->dob = $req['dob'];
        print_r($cust->toArray());
        $cust->save();
        return redirect('customer');
        
    }

}
