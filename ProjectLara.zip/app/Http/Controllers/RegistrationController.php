<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegistrationController extends Controller
{
    public function index(){
        return view('form');
    }
    public function register(Request $req){
        $req->validate(
            [
                'name'=>'required',
                'email'=>'required|email',
                'password'=>'required|confirmed',
                'confirm_password'=>'required'
            ]
        );
        print_r($req->all());

    }

    public function componentform(){
        return view('componentform');
    }
    public function componentformregister(Request $req){
        $req->validate(
            
            [
            'name'=>'required',
            'email'=>'required|email',
            'password'=>'required|confirmed',
            'password_confirmaion'=>'required'
            ]
        );
        //print_r($req->all());

    }
}

