<?php

use App\Http\Controllers\EmployeeCotroller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

//all emp
Route::get('employee',[EmployeeCotroller::class,'getEmp']);

//specific emp
Route::get('employee/{id}',[EmployeeCotroller::class,'getEmpSpecific']);

//add emp
Route::post('addEmp',[EmployeeCotroller::class,'addEmployee']);

//update emp
Route::put('update/{id}',[EmployeeCotroller::class,'updateEmp']);

//deleeteemp
Route::delete('delete/{id}',[EmployeeCotroller::class,'delData']);