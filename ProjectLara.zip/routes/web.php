<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DemoController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\SingleActionController;
use App\Http\Controllers\WebsiteController;
use Illuminate\Support\Facades\Route;
use App\Models\Customer;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/example/{name?}',function($name=null){
    $demo ="<h1>Welcode Brajdhan</h1>";
    $data =compact('name','demo');
    return view('/example/directive')->with($data);
});

// without controller

// Route::get('/', function(){
//     //return view('home');
// });

// Route::get('/about', function(){
//     return view('about');
// });

//with basic controller 
Route::get('/',[DemoController::class,'index']);
Route::get('/about',[DemoController::class,'about']);
// single ction controoler
Route::get('/courses',SingleActionController::class);
//resource controller
Route::resource('photo',PhotoController::class);

//registration controller
Route::get('/register', [RegistrationController::class,'index']);
Route::post('/register', [RegistrationController::class,'register']);
//componenet file input Data
Route::get('/componentform', [RegistrationController::class,'componentform']);
Route::post('/componentform', [RegistrationController::class,'componentformregister']);

// Route::get('/customer', function(){
//     $customers = Customer::all();
//     //print_r($customers->toArray());
//     return view('customer');
// }); 

Route::get('/customer/create',[CustomerController::class,'create'])->name('customer.create');
Route::get('/customer/delete/{id}',[CustomerController::class,'delete'])->name('customer.delete');
Route::get('/customer/edit/{id}',[CustomerController::class,'edit'])->name('customer.edit');
Route::post('/customer/update/{id}',[CustomerController::class,'update'])->name('customer.update');
Route::post('/customer',[CustomerController::class,'store']);
Route::get('/customer',[CustomerController::class,'view']);


Route::get('get-all-session', function(){
    $session = session()->all();
    brajdhan($session);
});

Route::get('set-session', function(Request $request)
{
    $request->session()->put('name',"brajdhan");
    $request->session()->put('id',"123");
    $request->session()->flash('status', 'success');
    return redirect('get-all-session');
});

Route::get('distroy-session', function(){
    session()->forget(['name','id']);
    //session()->forget('id');
    return redirect('get-all-session');
});

Route::get('mail',[WebsiteController::class,'index']);

